# metadata_extractor package
