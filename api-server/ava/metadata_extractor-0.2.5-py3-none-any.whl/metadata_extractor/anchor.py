"""
本模組 anchor.py 主要功能為：
- 從 PDF 檔案中提取文字元素及其座標資訊（bounding box），以利後續進行結構化的 metadata 擷取。
- 適用於可直接取得文字層的 PDF（非掃描圖片型 PDF 或純圖片檔）。
- 依賴多個第三方函式庫（如 pypdfium2、pypdf、PIL、LangChain 相關套件等），並定義了基礎的資料結構（如 BoundingBox），以便於描述與操作 PDF 文字區塊。
- 提供與 LLM（大型語言模型）整合的能力，協助進一步解析、理解與處理 PDF 內容。

注意事項：
- 本模組不適用於純圖片或掃描型 PDF（無法直接取得文字層）。
- 若需處理圖片型 PDF，請考慮使用 OCR 相關工具。

主要用途範例：
- 文件結構分析
- 文字區塊座標提取
- 文件內容摘要與語意理解

作者：<請填寫>
授權條款：<請填寫>
"""
import random
import re
import ftfy
import pypdfium2 as pdfium
from dataclasses import dataclass
from typing import List, Union, BinaryIO, Optional
from pypdf import PdfReader
from pypdf.generic import RectangleObject
import base64
from io import BytesIO
from typing import Tuple, Dict
from PIL import Image
from .output_parser import MarkdownStripperOutputParser
from .types import ChatModel
from langchain_community.callbacks.manager import get_openai_callback
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI, AzureChatOpenAI
from metadata_extractor.utils import to_base_chat_model
from .utils import decode_pdf_image

@dataclass(frozen=True)
class BoundingBox:
    x0: float; y0: float; x1: float; y1: float

    @staticmethod
    def from_rectangle(rect: RectangleObject) -> "BoundingBox":
        return BoundingBox(rect[0], rect[1], rect[2], rect[3])

@dataclass(frozen=True)
class TextElement:
    text: str; x: float; y: float

@dataclass(frozen=True)
class ImageElement:
    name: str; bbox: BoundingBox; data: bytes

@dataclass(frozen=True)
class PageReport:
    mediabox: BoundingBox
    text_elements: List[TextElement]
    image_elements: List[ImageElement]

def _transform_point(x, y, m):
    x_new = m[0]*x + m[2]*y + m[4]
    y_new = m[1]*x + m[3]*y + m[5]
    return x_new, y_new

def _mult(m: List[float], n: List[float]) -> List[float]:
    return [
        m[0]*n[0] + m[1]*n[2],
        m[0]*n[1] + m[1]*n[3],
        m[2]*n[0] + m[3]*n[2],
        m[2]*n[1] + m[3]*n[3],
        m[4]*n[0] + m[5]*n[2] + n[4],
        m[4]*n[1] + m[5]*n[3] + n[5],
    ]

def _pdf_report(local_pdf_path: Union[str, BinaryIO], page_num: int) -> PageReport:
    reader = PdfReader(local_pdf_path)
    page = reader.pages[page_num-1]
    resources = page.get("/Resources", {})
    xobjects = resources.get("/XObject", {})
    text_elements, image_elements = [], []

    def visitor_body(text, cm, tm, *_):
        txt2user = _mult(tm, cm)
        text_elements.append(TextElement(text, txt2user[4], txt2user[5]))

    def visitor_op(op, args, cm, *_):
        if op == b"Do":
            xobj = xobjects.get(args[0])
            if xobj and xobj["/Subtype"] == "/Image":
                x0, y0 = _transform_point(0, 0, cm)
                x1, y1 = _transform_point(1, 1, cm)
                bbox = BoundingBox(min(x0,x1),min(y0,y1),max(x0,x1),max(y0,y1))
                try:
                    img_data = decode_pdf_image(xobj)
                except Exception:
                    img_data = b""
                image_elements.append(ImageElement(args[0], bbox, img_data))

    page.extract_text(visitor_text=visitor_body, visitor_operand_before=visitor_op)
    return PageReport(
        mediabox=BoundingBox.from_rectangle(page.mediabox),
        text_elements=text_elements,
        image_elements=image_elements,
    )
    
def _merge_image_elements(images: List[ImageElement], tolerance: float = 0.5) -> List[ImageElement]:
    n = len(images)
    parent = list(range(n))  # Initialize Union-Find parent pointers

    def find(i):
        # Find with path compression
        root = i
        while parent[root] != root:
            root = parent[root]
        while parent[i] != i:
            parent_i = parent[i]
            parent[i] = root
            i = parent_i
        return root

    def union(i, j):
        # Union by attaching root of one tree to another
        root_i = find(i)
        root_j = find(j)
        if root_i != root_j:
            parent[root_i] = root_j

    def bboxes_overlap(b1: BoundingBox, b2: BoundingBox, tolerance: float) -> bool:
        # Compute horizontal and vertical distances between boxes
        h_dist = max(0, max(b1.x0, b2.x0) - min(b1.x1, b2.x1))
        v_dist = max(0, max(b1.y0, b2.y0) - min(b1.y1, b2.y1))
        # Check if distances are within tolerance
        return h_dist <= tolerance and v_dist <= tolerance

    # Union overlapping images
    for i in range(n):
        for j in range(i + 1, n):
            if bboxes_overlap(images[i].bbox, images[j].bbox, tolerance):
                union(i, j)

    # Group images by their root parent
    groups: dict[int, list[int]] = {}
    for i in range(n):
        root = find(i)
        groups.setdefault(root, []).append(i)

    # Merge images in the same group
    merged_images = []
    for indices in groups.values():
        # Initialize merged bounding box
        merged_bbox = images[indices[0]].bbox
        merged_name = images[indices[0]].name

        for idx in indices[1:]:
            bbox = images[idx].bbox
            # Expand merged_bbox to include the current bbox
            merged_bbox = BoundingBox(
                x0=min(merged_bbox.x0, bbox.x0),
                y0=min(merged_bbox.y0, bbox.y0),
                x1=max(merged_bbox.x1, bbox.x1),
                y1=max(merged_bbox.y1, bbox.y1),
            )
            # Optionally, update the name
            merged_name += f"+{images[idx].name}"

        # propagate data from the first image in the group
        merged_data = images[indices[0]].data
        merged_images.append(ImageElement(name=merged_name, bbox=merged_bbox, data=merged_data))

    # Return the merged images along with other elements
    return merged_images

def _cap_split_string(text: str, max_length: int) -> List[str]:
    #（可複製原本裡面對長字串切段的邏輯）
    if len(text) <= max_length:
        return text

    head_length = max_length // 2 - 3
    tail_length = head_length

    head = text[:head_length].rsplit(" ", 1)[0] or text[:head_length]
    tail = text[-tail_length:].split(" ", 1)[-1] or text[-tail_length:]

    return f"{head} ... {tail}"

def _cleanup_element_text(element_text: str) -> str:
    MAX_TEXT_ELEMENT_LENGTH = 250
    TEXT_REPLACEMENTS = {"[": "\\[", "]": "\\]", "\n": "\\n", "\r": "\\r", "\t": "\\t"}
    text_replacement_pattern = re.compile("|".join(re.escape(key) for key in TEXT_REPLACEMENTS.keys()))

    element_text = ftfy.fix_text(element_text).strip()

    # Replace square brackets with escaped brackets and other escaped chars
    element_text = text_replacement_pattern.sub(lambda match: TEXT_REPLACEMENTS[match.group(0)], element_text)

    return _cap_split_string(element_text, MAX_TEXT_ELEMENT_LENGTH)#（可複製原本裡面清理亂碼／空白的邏輯）


def _linearize_pdf_report(report: PageReport, max_length: int = 4000) -> Tuple[str, Dict[str, str]]:
    result = ""
    result += f"Page dimensions: {report.mediabox.x1:.1f}x{report.mediabox.y1:.1f}\n"

    if max_length < 20:
        return result, {}

    images = _merge_image_elements(report.image_elements)

    # Process image elements
    image_strings: list[tuple[ImageElement, str]] = []
    image_map: Dict[str, str] = {}
    for element in images:
        # generate random hex filename
        filename = ''.join(random.choice("0123456789abcdef") for _ in range(16)) + ".jpg"
        # encode image data to base64
        b64_str = base64.b64encode(element.data).decode("ascii")
        image_map[filename] = b64_str
        image_str = f"[Image: {filename}  {element.bbox.x0:.0f}x{element.bbox.y0:.0f} to {element.bbox.x1:.0f}x{element.bbox.y1:.0f}]\n"
        image_strings.append((element, image_str))

    # Process text elements
    text_strings = []
    for element in report.text_elements:  # type: ignore
        if len(element.text.strip()) == 0:  # type: ignore
            continue

        element_text = _cleanup_element_text(element.text)  # type: ignore
        text_str = f"[{element.x:.0f}x{element.y:.0f}]{element_text}\n"  # type: ignore
        text_strings.append((element, text_str))

    # Combine all elements with their positions for sorting
    all_elements: list[tuple[str, ImageElement, str, tuple[float, float]]] = []
    for elem, s in image_strings:
        # 這裡定義 position
        position = (elem.bbox.x0, elem.bbox.y0)
        all_elements.append(("image", elem, s, position))

    # 再處理文字
    for elem, s in text_strings:
        # 這裡也要定義 position
        position = (elem.x, elem.y)
        all_elements.append(("text", elem, s, position))

    # Calculate total length
    total_length = len(result) + sum(len(s) for _, _, s, _ in all_elements)

    if total_length <= max_length:
        # Include all elements
        for _, _, s, _ in all_elements:
            result += s
        return result, image_map

    # Identify elements with min/max coordinates
    edge_elements = set()

    if images:
        min_x0_image = min(images, key=lambda e: e.bbox.x0)
        max_x1_image = max(images, key=lambda e: e.bbox.x1)
        min_y0_image = min(images, key=lambda e: e.bbox.y0)
        max_y1_image = max(images, key=lambda e: e.bbox.y1)
        edge_elements.update([min_x0_image, max_x1_image, min_y0_image, max_y1_image])

    if report.text_elements:
        text_elements = [e for e in report.text_elements if len(e.text.strip()) > 0]
        if text_elements:
            min_x_text = min(text_elements, key=lambda e: e.x)
            max_x_text = max(text_elements, key=lambda e: e.x)
            min_y_text = min(text_elements, key=lambda e: e.y)
            max_y_text = max(text_elements, key=lambda e: e.y)
            edge_elements.update([min_x_text, max_x_text, min_y_text, max_y_text])  # type: ignore

    # Keep track of element IDs to prevent duplication
    selected_element_ids = set()
    selected_elements = []

    # Include edge elements first
    for elem_type, elem, s, position in all_elements:
        if elem in edge_elements and id(elem) not in selected_element_ids:
            selected_elements.append((elem_type, elem, s, position))
            selected_element_ids.add(id(elem))

    # Calculate remaining length
    current_length = len(result) + sum(len(s) for _, _, s, _ in selected_elements)
    _remaining_length = max_length - current_length

    # Exclude edge elements from the pool
    remaining_elements = [(elem_type, elem, s, position) for elem_type, elem, s, position in all_elements if id(elem) not in selected_element_ids]

    # Shuffle remaining elements randomly
    random.shuffle(remaining_elements)

    # Add elements until reaching max_length
    for elem_type, elem, s, position in remaining_elements:
        if current_length + len(s) > max_length:
            break
        selected_elements.append((elem_type, elem, s, position))
        selected_element_ids.add(id(elem))
        current_length += len(s)

    # Sort selected elements by their positions to maintain logical order
    selected_elements.sort(key=lambda x: (x[3][0], x[3][1]))

    # Build the final result
    for _, _, s, _ in selected_elements:
        result += s

    return result, image_map

def get_anchor_text_pdfreport(
    local_pdf_path: Union[str, BinaryIO], page: int, target_length: int = 8000
) -> Tuple[str, Dict[str, str]]:
    """
    擷取指定 PDF 頁面的 anchor 文字與圖片 base64 編碼。

    Args:
        local_pdf_path (str | BinaryIO): PDF 檔案路徑或檔案物件。
        page (int): 頁碼（從 1 開始）。
        target_length (int): 文字最大長度，預設 4000。

    Returns:
        Tuple[str, Dict[str, str]]: 
            - 第一個回傳值為 anchor 文字 (str)
            - 第二個回傳值為圖片 base64 字典 (dict)，格式為 {filename: base64_str}
              filename 為隨機 16 位小寫十六進位字串（含 .jpg 副檔名）
              base64_str 為對應圖片的 base64 字串
    """
    assert page > 0
    return _linearize_pdf_report(
        _pdf_report(local_pdf_path, page),
        max_length=target_length
    )

def pdf_to_text_by_anchor(
    pdf: BinaryIO,
    llm: Union[str, ChatModel],
    model: str = None,
    use_image: bool = False,
    page: Optional[int] = None,
    target_length=8000
) -> Tuple[str, Dict]:
    """
    將 PDF 的文字透過 get_anchor_text_pdfreport 及 anchor_to_text 轉換為可讀文字，可指定單一頁面或全部頁面。

    Args:
        pdf (BinaryIO): PDF 文件的二進制流。
        llm (Union[str, ChatModel]): LLM 模型或模型名稱。
        model (str, optional): LLM 模型名稱。
        use_image (bool, optional): 是否使用圖片轉換。預設為 False。
        page (Optional[int], optional): 指定要處理的頁碼（從 1 開始）。None 則處理所有頁面。

    Returns:
        Tuple[str, Dict]:
            - 第一個回傳值為經 LLM 處理後的可讀文字（str）。
            - 第二個回傳值 metadata（dict），內容包含：
                - token_usage：dict，紀錄本次 LLM 推論所消耗的 token 數量（prompt_tokens, completion_tokens, total_tokens）。
                - images：dict，所有圖片的 base64 字典，格式為 {filename: base64_str}
                - 其他流程相關輔助資訊（如未來可擴充 OCR、圖片處理等統計資訊）。
        metadata 結構範例：
            {
                "token_usage": {
                    "prompt_tokens": 123,
                    "completion_tokens": 456,
                    "total_tokens": 579
                },
                "images": {
                    "xxxxxxxxxxxxxxxx.jpg": "base64string...",
                    ...
                }
            }
        這份 metadata 便於日後進行效能分析、成本統計、流程除錯與追蹤。
    """
    llm = to_base_chat_model(llm)
    
    content = pdf.read()
    if use_image:
        doc = pdfium.PdfDocument(BytesIO(content))
    reader = PdfReader(BytesIO(content))
    num_pages = len(reader.pages)
    texts: list[str] = []
    total_prompt_tokens = 0
    total_completion_tokens = 0
    total_tokens = 0
    all_images: dict = {}

    if page is not None:
        # 僅處理單一頁面
        page_indices = [page]
    else:
        # 處理所有頁面
        page_indices = list(range(1, num_pages + 1))

    for idx in page_indices:
        page_stream = BytesIO(content)
        anchor_text, image_map = get_anchor_text_pdfreport(page_stream, idx, target_length=target_length)
        if use_image:
            page_obj = doc.get_page(idx-1)
            bitmap = page_obj.render()
            pil_img = bitmap.to_pil()
            pil_img.thumbnail((1024, 1024), Image.Resampling.LANCZOS)
            text, metadata = anchor_to_text(anchor_text, llm, model, image=pil_img, image_map=image_map)
            page_obj.close()
        else:
            text, metadata = anchor_to_text(anchor_text, llm, model, image_map=image_map)
        texts.append(text)
        tu = metadata.get("token_usage", {})
        total_prompt_tokens += tu.get("prompt_tokens", 0)
        total_completion_tokens += tu.get("completion_tokens", 0)
        total_tokens += tu.get("total_tokens", 0)        
        # 合併 images
        images = metadata.get("images", {})
        if images:
            all_images.update(images)
    combined_text = "\n\n".join(texts)
    combined_metadata = {
        "token_usage": {
            "prompt_tokens": total_prompt_tokens,
            "completion_tokens": total_completion_tokens,
            "total_tokens": total_tokens,
        },
        "images": all_images
    }
    if use_image:
        doc.close()
    return combined_text, combined_metadata


def anchor_to_text(anchor_text: str, llm: Union[str, ChatModel], model: str=None, image: Optional[Image.Image] = None, image_map: Dict[str, str] = {}) -> Tuple[str, dict]:
    """
    將帶有 anchor_text 的文字透過LLM轉換為可讀文字
     
     Args:
         anchor_text (str): 帶有 anchor_text 的文字
         llm (Union[str, ChatModel]): LLM 模型或模型名稱
         model (str, optional): LLM 模型名稱. 如果沒有指定直接使用傳入的 llm 的 model name，若有則更換 model
         image (Image.Image, optional): 需要轉換的圖片，如果沒有圖片，則不使用圖片，直接使用 anchor 轉換為可讀文字
         image_map (dict, optional): 圖片 base64 字典，格式為 {filename: base64_str}
     
     Returns:
         Tuple[str, dict]:
             - 第一個回傳值為經 LLM 處理後的可讀文字（str）。
             - 第二個回傳值 metadata（dict），內容包含：
                 - token_usage：dict，紀錄本次 LLM 推論所消耗的 token 數量（prompt_tokens, completion_tokens, total_tokens）。
                 - images：dict，所有圖片的 base64 字典，格式為 {filename: base64_str}
                 - 其他流程相關輔助資訊（如未來可擴充 OCR、圖片處理等統計資訊）。
             metadata 結構範例：
                 {
                     "token_usage": {
                         "prompt_tokens": 123,
                         "completion_tokens": 456,
                         "total_tokens": 579
                     },
                     "images": {
                         "xxxxxxxxxxxxxxxx.jpg": "base64string...",
                         ...
                     }
                 }
             這份 metadata 便於日後進行效能分析、成本統計、流程除錯與追蹤。
     """
    # 如果指定新的 model，根據 LLM 類型更新對應欄位
    if model is not None:
        llm = to_base_chat_model(llm, model)

    system_prompt = (
        "Below is the image of one page of a document, as well as some raw textual content that was previously extracted for it. "
        "Just return the markdown representation of this document as if you were reading it naturally.\nDo not hallucinate. \n"
        "For empty cells, fill them with '-'."
    )
    if image is not None:
        buffer = BytesIO()
        image.save(buffer, format="PNG")
        img_b64 = base64.b64encode(buffer.getvalue()).decode("utf-8")
        prompt = ChatPromptTemplate.from_messages([
            ("system", system_prompt),
            ("user", [
                {"type": "image_url", "image_url": {"url": "data:image/png;base64,{image_data}"}},
                {"type": "text", "text": "RAW_TEXT_START\n{text}\nRAW_TEXT_END"}
            ])
        ])
        invoke_vars = {"image_data": img_b64, "text": anchor_text}
    else:
        prompt = ChatPromptTemplate.from_messages([
            ("system", system_prompt),
            ("user", "RAW_TEXT_START\n{text}\nRAW_TEXT_END")
        ])
        invoke_vars = {"text": anchor_text}

    parser = MarkdownStripperOutputParser()
    chain = prompt | llm | parser
    with get_openai_callback() as cb:
        text_result = chain.invoke(invoke_vars)
    metadata = {
        "token_usage": {
            "prompt_tokens": cb.prompt_tokens,
            "completion_tokens": cb.completion_tokens,
            "total_tokens": cb.total_tokens,
        }
    }
    metadata.setdefault("images", {})
    metadata["images"] = image_map
    return text_result, metadata