"""
本模組 extractor.py 主要功能為：
- 提供從文字、PDF 或圖片等多種來源提取 metadata（中繼資料）的相關方法。
- 支援多種 LLM（大型語言模型）驅動的 metadata 擷取流程，並可整合 OpenAI、Azure OpenAI 以及 LangChain 相關模型。
- 定義了模型轉換、文字提取、結構化輸出解析等關鍵流程，方便用戶以統一介面進行 metadata 擷取。

核心功能包含：
- LLM 模型包裝與轉換（支援多種 API 及模型型別）
- PDF 文字區塊座標與內容提取
- OCR 文字提取（透過 Mistral 等工具）
- 結構化 JSON 輸出解析

適用場景：
- 文件自動化結構分析
- 內容摘要與知識擷取
- 跨來源（PDF、圖片、文字）metadata 統一提取

依賴套件：
- openai, langchain, pypdf, PIL 等
"""
from typing import Literal, Union, Tuple, Optional
from openai import OpenAI, AzureOpenAI
from langchain_openai import ChatOpenAI, AzureChatOpenAI
from langchain_core.language_models import BaseChatModel
from metadata_extractor.types import ChatModel
from langchain_core.output_parsers import JsonOutputParser
from langchain_core.prompts import PromptTemplate
from metadata_extractor.anchor import pdf_to_text_by_anchor
from metadata_extractor.mistral import mistral_ocr_extract_text
from typing import BinaryIO
from langchain_community.callbacks.manager import get_openai_callback
from metadata_extractor.utils import to_base_chat_model

# 這裡可以放各種 extractor 實作
def extract_metadata(
    metadata_schema: str,
    input_data: Union[str, BinaryIO],
    model: Union[str, ChatModel] = "gpt-4o-mini",
    text_extration_method: Literal["anchor_to_text", "mistral_ocr"] = "anchor_to_text",
    text_extration_model: Optional[Union[str, ChatModel]] = None
) -> Tuple[dict, dict]:
    """
    從輸入資料中提取 metadata，可處理純文字、圖片或 PDF 二進制流。

    Args:
        metadata_schema (str):
            JSON Schema 的字串，指定要提取的欄位結構。
        input_data (Union[str, BinaryIO]):
            純文字、圖片或 PDF 文件的二進制流。
        model (Union[str, ChatModel], optional):
            LLM 模型，可為模型名稱字串、OpenAI/AzureOpenAI client，
            或 BaseChatModel 子類別，預設為 "gpt-4o-mini"。
        text_extration_method (Literal["anchor_to_text", "mistral_ocr"]):
            文字提取方法。anchor_to_text 走座標區塊，mistral_ocr 走 OCR。
        text_extration_model (Optional[Union[str, ChatModel]]):
            文字提取專用 LLM 模型，若未指定則與 model 相同。

    Returns:
        Tuple[dict, dict]:
            第一個 dict 為 metadata 抽取結果（符合 schema 的結構化資料）。
            第二個 dict 為本次處理過程的詳細 metadata，內容包含：
                - token_usage：dict，紀錄本次 LLM 推論所消耗的 token 數量（prompt_tokens, completion_tokens, total_tokens）。
                  若有經過 anchor_to_text/pdf_to_text_by_anchor，則此欄位會加總所有步驟的 token 用量。
                - 來源處理資訊：如 OCR 或 anchor 處理流程的細節與統計資訊（例如每頁 token 用量）。
                - 其他依據不同流程可能產生的輔助資訊。
            metadata 結構範例：
                {
                    "token_usage": {
                        "prompt_tokens": 123,
                        "completion_tokens": 456,
                        "total_tokens": 579
                    },
                    ... # 其他流程相關資訊
                }
            這份 metadata 便於日後進行效能分析、成本統計、流程除錯與追蹤。
    """
    llm = to_base_chat_model(model)
    if text_extration_model:
        text_extration_llm = to_base_chat_model(text_extration_model)
    else:
        text_extration_llm = llm
    parser = JsonOutputParser()

    # 根據 text_extration_method 處理文字抽取
    if isinstance(input_data, str):
        # 純文字直接使用，不經過任何 OCR 或 anchor 處理
        raw_text = input_data
    elif text_extration_method == 'mistral_ocr':
        if not hasattr(input_data, 'read'):
            raise ValueError('input_data 必須是 PDF 文件二進制流，才能使用 mistral_ocr 方法')
        raw_text = mistral_ocr_extract_text(input_data)
    elif text_extration_method == 'anchor_to_text':
        if hasattr(input_data, 'read'):
            raw_text, metadata = pdf_to_text_by_anchor(input_data, llm, use_image=True)
        else:
            raise ValueError('input_data 必須是字串或 PDF 二進制流，才能使用 anchor_to_text 方法')    

    prompt = PromptTemplate(
        template=(
            "請從以下內容中提取 metadata，並以符合下列 JSON Schema 的格式輸出：\n"
            "```json\n"
            "{schema}\n"
            "```\n"
            "{format_instructions}\n"
            "內容如下：\n"
            "{text}\n"
        ),
        input_variables=["schema", "text"],
        partial_variables={"format_instructions": parser.get_format_instructions()},
    )

    # TODO: 統計 Mistral OCR 處理時所翻譯的頁數，並將資訊納入 metadata
    chain = prompt | text_extration_llm | parser
    # 使用 LangChain callback 取得 token 用量，並合併到 metadata
    
    with get_openai_callback() as cb:
        result = chain.invoke({"schema": metadata_schema, "text": raw_text})
    # 合併 token 用量到 metadata
    token_usage = {
        "prompt_tokens": cb.prompt_tokens,
        "completion_tokens": cb.completion_tokens,
        "total_tokens": cb.total_tokens,
    }
    if 'metadata' in locals() and metadata is not None:
        if isinstance(metadata, dict):
            metadata = {**metadata, "token_usage": token_usage}
        else:
            metadata = {"token_usage": token_usage}
    else:
        metadata = {"token_usage": token_usage}
        
    return result, metadata