# 新增 Mistral OCR 處理函數，支援 PDF 與影像
from typing import BinaryIO, Optional
import os
from mistralai import Mistral
from metadata_extractor.utils import is_pdf, is_image

def mistral_ocr_extract_text(file_stream: BinaryIO, client: Optional[Mistral] = None) -> str:
    """
    使用 Mistral OCR 處理 PDF 或影像檔，回傳合併後的 markdown 文字內容。
    需要 MISTRAL_API_KEY 環境變數。
    
    Args:
        file_stream (BinaryIO): PDF 或影像檔的二進制流
        client (Optional[Mistral]): Mistral 客戶端，若未指定則使用環境變數的MISTRAL_API_KEY來初始化Mistral Client
    
    Returns:
        str: 合併後的 markdown 文字內容
    """
    if client is None:
        api_key = os.environ.get("MISTRAL_API_KEY")
        assert api_key, "請將 Mistral API Key 設定於 MISTRAL_API_KEY 環境變數！"
        client = Mistral(api_key=api_key)
    
    file_stream.seek(0)
    if is_pdf(file_stream):
        uploaded = client.files.upload(
            file={"file_name": "uploaded_file.pdf", "content": file_stream},
            purpose="ocr"
        )
        signed = client.files.get_signed_url(file_id=uploaded.id)
        document = {"type": "document_url", "document_url": signed.url}
    elif is_image(file_stream):
        uploaded = client.files.upload(
            file={"file_name": "uploaded_file.png", "content": file_stream},
            purpose="ocr"
        )
        signed = client.files.get_signed_url(file_id=uploaded.id)
        document = {"type": "image_url", "image_url": signed.url}
    else:
        raise RuntimeError("檔案類型不支援")
    
    ocr_response = client.ocr.process(
        model="mistral-ocr-latest",
        document=document
    )
    if ocr_response.pages:
        texts = [p.markdown for p in ocr_response.pages if p.markdown]
        return "\n\n".join(texts)
    else:
        raise RuntimeError("Mistral OCR 未能正確取得檔案內容")