import re
from langchain_core.output_parsers import BaseOutputParser

class MarkdownStripperOutputParser(BaseOutputParser):
    """
    將 LLM 輸出移除 markdown code block 標記（如 ```markdown ... ``` 或 ``` ... ```），僅保留純 markdown 內容。
    若無 code block，則原樣回傳。
    
    Args:
        text (str): 輸入的 LLM 輸出
    
    Returns:
        str: 移除 markdown code block 的純 markdown 內容
    """
    def parse(self, text: str) -> str:
        # 移除 ```markdown ... ``` 或 ``` ... ``` block
        match = re.search(r"```(?:markdown)?\n?(.*?)```", text, re.DOTALL)
        if match:
            return match.group(1).strip()
        return text.strip()
