"""
Common type aliases for metadata_extractor package
"""
from typing import Union
from openai import OpenAI, AzureOpenAI
from langchain_core.language_models import BaseChatModel

# Combined Chat model return type
ChatModel = Union[OpenAI, AzureOpenAI, BaseChatModel]
