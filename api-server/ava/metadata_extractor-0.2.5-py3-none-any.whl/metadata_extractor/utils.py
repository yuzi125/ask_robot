"""
輔助工具
"""

from typing import BinaryIO, Union, Optional
from openai import OpenAI, AzureOpenAI
from langchain_openai import ChatOpenAI, AzureChatOpenAI
from langchain_core.language_models import BaseChatModel
from metadata_extractor.types import ChatModel
from typing import Any
from PIL import Image
import io

def is_pdf(f: BinaryIO) -> bool:
    """
    判斷是否為 PDF 檔案
    
    Args:
        f (BinaryIO): 檔案二進制流
    
    Returns:
        bool: 是否為 PDF 檔案
    """
    pos = f.tell()
    header = f.read(5)
    f.seek(pos)
    return header == b"%PDF-"

def is_image(f: BinaryIO) -> bool:
    """
    判斷是否為影像檔案
    
    Args:
        f (BinaryIO): 檔案二進制流
    
    Returns:
        bool: 是否為影像檔案
    """ 
    from imghdr import what
    pos = f.tell()
    data = f.read(32)
    f.seek(pos)
    return what(None, data) in ("jpeg", "png", "gif", "bmp", "tiff")

def to_base_chat_model(model: Union[str, ChatModel], model_name: Optional[str]=None) -> BaseChatModel:
    """
    將 LLM 模型轉換為 BaseChatModel

    Args:
        model (Union[str, ChatModel]):
            LLM 模型，可以為字串（模型名稱）、OpenAI client、AzureOpenAI client，
            或 LangChain 的 BaseChatModel 子類別。
            當此參數為字串時，預設使用 ChatOpenAI 建立 LLM，
            並將該字串作為模型名稱。
        model_name (str, optional):
            指定模型名稱，當 model 為 OpenAI 或 AzureOpenAI client 時可指定，
            其他型別則忽略。

    Returns:
        BaseChatModel: 轉換後的 BaseChatModel 實例
    """
    if isinstance(model, str):
        return ChatOpenAI(model=model)
    if isinstance(model, OpenAI):
        # 無論有沒有 model_name，都要回傳 ChatOpenAI 實例
        return ChatOpenAI(client=model, model=model_name) if model_name else ChatOpenAI(client=model)
    if isinstance(model, AzureOpenAI):
        # 無論有沒有 model_name，都要回傳 AzureChatOpenAI 實例
        return AzureChatOpenAI(client=model, model=model_name) if model_name else AzureChatOpenAI(client=model)
    # 已經是 BaseChatModel 或其子類別，直接回傳
    return model

# MOVED: extract_text_by_mistral_ocr 已移至 mistral.py

def decode_pdf_image(xobj: Any) -> bytes:
    """Decode a PDF image XObject into PNG image bytes."""
    filters = xobj.get("/Filter")

    if not isinstance(filters, list):
        filters = [filters]

    width = xobj["/Width"]
    height = xobj["/Height"]

    # 預設 mode
    mode = None

    # 判斷 ColorSpace
    color_space = xobj["/ColorSpace"]
    if isinstance(color_space, list) and color_space[0] == "/ICCBased":
        icc_profile = color_space[1].get_object()
        n_components = icc_profile["/N"]
        if n_components == 1:
            mode = "L"
        elif n_components == 3:
            mode = "RGB"
        elif n_components == 4:
            mode = "CMYK"
        else:
            raise ValueError(f"Unsupported ICC ColorSpace N={n_components}")
    elif color_space == "/DeviceRGB":
        mode = "RGB"
    elif color_space == "/DeviceGray":
        mode = "L"
    elif color_space == "/DeviceCMYK":
        mode = "CMYK"
    else:
        raise ValueError(f"Unsupported ColorSpace: {color_space}")

    # 抓原始資料
    data = xobj.get_data()

    # 決定是要 frombytes 還是直接 open
    if "/DCTDecode" in filters or "/JPXDecode" in filters:
        # JPEG, JPEG2000
        image = Image.open(io.BytesIO(data))
    else:
        # Raw Bitmap
        image = Image.frombytes(mode, (width, height), data)

    # 統一轉存成標準 PNG
    output = io.BytesIO()
    image.save(output, format="PNG")
    return output.getvalue()